google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(chartTime);
function chartTime(){
    $.ajax({url:"data.xml", dataType:"xml",
	    success:function(x, status){

		
		drawChart(x);
	    }});

		console.log("test1");
}
function drawChart(data) {
    var toto = {};
    var ans = {};
    $( 'LineItem', data).each(function (){
	console.log("line item found");
	var serviceAgency = $('ServiceAgencyName',this).text();
	if (ans[serviceAgency] == null){
	    ans[serviceAgency] = [0,0,0,0];
	}
	var currentYearCost = Number($(this).xpath('*:ResourceSummary/*:TotalCost/*:CurrentYear').text());
	console.log($(this).xpath('*:ResourceSummary/*:TotalCost/*:CurrentYear').text());
	console.log(currentYearCost);
	if (! currentYearCost > 0){
	   //do nothing
	}else if (currentYearCost < 10){
	    ans[serviceAgency][0]++;
	} else	if (currentYearCost < 20){
	    ans[serviceAgency][1]++;
	} else if (currentYearCost < 70){
	    ans[serviceAgency][2]++;
	} else{
	    ans[serviceAgency][3]++;
	}
	if (isNaN(toto[serviceAgency])){
	    toto[serviceAgency]   = 0;
	}
	toto[serviceAgency] += currentYearCost;
    });

    var chartData = [["Service Agency", "CY lineItem totals < 10", "CY lineItem totals < 20","CY lineItem totals >20 and <70", "CY lineItem totals >70"]];
    for (var i in ans){
	chartData.push([i, ans[i][0], ans[i][1], ans[i][2], ans[i][3]]);
    }
    chartData = google.visualization.arrayToDataTable(chartData);

    var pieData = [["Service Agency", "current year total"]];
    for (var i in toto){
	pieData.push([i, toto[i]]);
    } 
    pieData = google.visualization.arrayToDataTable(pieData);
    var areaChart = new google.visualization.AreaChart(document.getElementById('area_chart_div'));
    var columnChart = new google.visualization.ColumnChart(document.getElementById('bar_chart_div'));
    var pieChart = new google.visualization.PieChart(document.getElementById('pie_chart_div'));

    var areaoptions = {
        title: "size of currentYear p1 totals across agency's",
        hAxis: {title: 'Service Agency',  titleTextStyle: {color: '#333'}},
        vAxis: {minValue: 0}
    };
    var columnOptions = {
        title: "size of currentYear p1 totals across agency's",
        hAxis: {title: 'Service Agency',  titleTextStyle: {color: '#333'}},
        vAxis: {minValue: 0}
    };
    var pieOptions = {
        title: "size of currentYear p1 totals across agency's"
    };
        
    columnChart.draw(chartData, columnOptions);
    areaChart.draw(chartData, areaoptions);
    pieChart.draw(pieData, pieOptions);
}